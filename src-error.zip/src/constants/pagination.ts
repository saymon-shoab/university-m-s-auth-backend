export const paginationFields = ['page', 'limit', 'sortBy', 'sortOrder']
