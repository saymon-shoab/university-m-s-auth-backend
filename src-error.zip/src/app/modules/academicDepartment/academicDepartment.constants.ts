export const academicDepartmentFilterableFields = ['searchTerm', 'title']

export const academicDepartmentSearchableFields = ['title']
