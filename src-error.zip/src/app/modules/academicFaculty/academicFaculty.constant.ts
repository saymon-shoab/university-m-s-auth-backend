export const academicFacultyFilterableFields = ['searchTerm', 'title']

export const academicFacultySearchableFields = ['title']
